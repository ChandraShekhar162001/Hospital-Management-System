<div class="sidebar app-aside" id="sidebar" >
				<div class="sidebar-container perfect-scrollbar" style="background-color: #404040">

<nav>
						
						<!-- start: MAIN NAVIGATION MENU -->
						<div class="navbar-title" style="color: #FFFFFF;">
							<span>Main Navigation</span>
						</div>
						<ul class="main-navigation-menu">
							<li>
								<a href="dashboard.php">
									<div class="item-content" style="background-color: #404040" >
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title" style="color: #FFFFFF;"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
							

							<li>
								<a href="appointment-history.php">
									<div class="item-content" style="background-color: #404040">
										<div class="item-media">
											<i class="ti-list"></i>
										</div>
										<div class="item-inner">
											<span class="title" style="color: #FFFFFF; "> Appointment History </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="javascript:void(0)">
									<div class="item-content" style="background-color: #404040;">
										<div class="item-media">
											<i class="ti-user"></i>
										</div>
										<div class="item-inner">
											<span class="title" style="color: #FFFFFF;"> Patients </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu" style="background-color: #404040;">
									
									<li>
										<a href="add-patient.php">
											<span class="title" style="color: #ffffff"> Add Patient</span>
										</a>
									</li>
									<li>
										<a href="manage-patient.php">
											<span class="title" style="color: #ffffff;"> Manage Patient </span>
										</a>
									</li>
									
								</ul>
								</li>
<li>
								<a href="search.php">
									<div class="item-content" style="background-color: #404040">
										<div class="item-media">
											<i class="ti-search" ></i>
										</div>
										<div class="item-inner" style="background-color: #404040">
											<span class="title" style="color: #ffffff"> Search </span>
										</div>
									</div>
								</a>
							</li>

						</ul>
						<!-- end: CORE FEATURES -->
						
					</nav>
					</div>
			</div>